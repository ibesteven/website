import random, os, datetime, pickle, pygame, json
class aster:
    def __init__(self):
        self.spawn = True
        self.location = 0
        self.asteroid = None
        self.visible = True
HEIGHT = 700
WIDTH = 1280
energy = 100
new_direction = "idle"
game_status = "beginnings"
background = "nebula aqua-pink"
player = Actor("pitrizzo-spaceship-gpl3-opengameart-96x96", (WIDTH/2, 600))
points = 0
spawnc = 1
testfileread = ""
pointslist = []
listsecond = []
pointslistpoints = {}
pointslistdate = {}
pointslistname = {}
pointsddictfinal = []
speed = 1
num = 0
a = 0
shoot = False
writetrue = True
health = 3
energy = 100
asdasd = 0
asteroid = aster()
asteroids = [asteroid]
font = pygame.font.Font(None, 40)
user_input = ""
textboxcoloractive = pygame.Color("lightskyblue3")
textboxcolorinactive = pygame.Color("gray15")
textboxcolor = textboxcolorinactive
textbox = pygame.Rect(400,500,140,32)
active = False
user_input_list = {}
with open("C:/Users/helle/mu_code/shooter_game/testfile.json","r") as testfile:
    readfile = json.load(testfile)
def draw():
    global readfile, a, user_input_list, input_surface, screene, textboxcolor, textbox, user_input, asdasd, pointsdictpickled, testfileread, scores, forloop, readvalue, writetrue, asteroids, laser0, shoot, health, points, energy, game_status,speed,file,fileb,filefinal
    a = 0
    if game_status != "start":
        if game_status == "end":
            a += 1
            if a == 1:
                pointslist.append(str(points) + " " + datetime.datetime.now().strftime("%Y/%m/%d/%H:%M:%S") + " " + user_input)
        if health == 0 or energy == 1:
            user_input = ""
        screene = pygame.display.set_mode([WIDTH, HEIGHT])
        screen.blit(background, (0, 0))
        pygame.Surface.set_clip(screene, None)
        pygame.draw.rect(screene,textboxcolor,textbox,4)
        screen.blit(input_surface,(textbox.x + 5,textbox.y + 5))
        textbox.w = max(150,input_surface.get_width() + 10)
        a = True
        spawnc = 1
        health = 3
        asteroids = [asteroid]
        for ast in asteroids:
            ast.visible = True
            ast.spawn = True
            ast.asteroid.location = 0
        points = 0
        screen.draw.text("scores:" + "\n", (0, 0), fontsize=20, color=(255, 255, 255))
        asdasd = 20
        #for i in pointsdictpickled.keys():
            #screen.draw.text(str(i) + " " + str((pointsdictpickled[i])[0].keys()) + " " + str((((pointsdictpickled[i])[0]).get(i)).values()), center=(200, asdasd), fontsize=20, color=(255, 255, 255))
        #    asdasd += 20
        screen.draw.text("write name to start, press keypad enter to confirm", center=(WIDTH/2, HEIGHT/2), fontsize=60, color=(255, 255, 255))
    else:
        screen.clear()
        screen.blit(background, (0, 0))
        player.draw()
        healthbar = Rect(((player.x - (health * 33/2)), player.y), ((health * 33), 1))
        screen.draw.filled_rect(healthbar, (255, 0, 0))
        energybar = Rect((WIDTH/2, 25), (energy, 60))
        energybar.center = ((WIDTH/2, 25))
        if energy > 0:
            screen.draw.filled_rect(energybar, (0, 0, 255))
        else:
            game_status = "end"
            a = 0
        for ast in asteroids:
            ast.asteroid.y += speed
        for ast in asteroids:
            if ast.visible:
                ast.asteroid.draw()
        screen.draw.text(str(health), center=(player.x, player.y), fontsize=60, color=(255, 0, 0))
        screen.draw.text(("score:" + str(points)), center=(WIDTH/2, 60), fontsize=60, color=(255, 255, 255))
        if (keyboard.s) or (keyboard.down):
            shoot = True
            sounds.sfx_laser2.play()
            laser0 = Rect(((player.x - 5), 0), ((10), player.y - 50))
            screen.draw.filled_rect(laser0, (255, 0, 0))

def update():
    global pointslistdate, pointslist, pointslistpoints, a, pointslistname, textpoints, num, pointslistfinal, textboxcolor, textboxcolorinactive, textboxcoloractive, active, textbox, input_surface, event, font, user_input,user_text, pointsdictpickled, testfileread, readvaule, pointsb, energy, shoot, game_status, speed, points, health, asteroids, new_direction, laser0
    pointsb = []
    if health == 0 or energy == 1:
        user_input = ""

        #for point in read_text:
            #b = point.strip("\n")
            #c = b.split(" ")
            #pointsb.append(c)
            #c[0] = int(c[0])
    #read_text.close()
    for i in range(len(pointsb)):

       # pointslist[(pointsb[i])[2]]= (pointsb[i])[1]
       # pointsdictfinal[(pointsb[i])[0]] = pointslist
    #sorted(pointsdictfinal.keys(),reverse = True)
    #for a in sorted(pointslistfinal.keys(),reverse = True):
        num += 1
            #pickle.dump(pointsdict,testfile)
    speed = points/20 + 1
    if len(asteroids) < int(points/10 + 1):
        asteroid = aster()
        asteroids.append(asteroid)
        laser0 = Rect(((player.x - 5), 0), ((10), player.y - 50))
    if game_status == "end":
        pointslist.append(str(points) + " " + datetime.datetime.now().strftime("%Y/%m/%d/%H:%M:%S"))
        #if points in pointsdict.keys():
        #    pointsdict[points].append(pointslist)
        #else:
        #    pointsdict[points] = pointslist
        #print(pointslist)
        for ast in asteroids:
            if not asteroids[0]:
                asteroids.remove[ast]
            ast.location = 0
            ast.visible = True
            ast.spawn = True
        health = 3
        points = 0
        energy = 100
    if game_status != "start":
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.KEYDOWN:
                if event.type == pygame.K_LSHIFT or pygame.K_RSHIFT:
                    active = True
            if event.type == pygame.MOUSEBUTTONDOWN:
                if textbox.collidepoint(event.pos):
                    active = True
                else:
                    active = False
                if active:
                    textboxcolor = textboxcoloractive
                else:
                    textboxcolor = textboxcolorinactive
            elif event.type == pygame.KEYDOWN:
                if active == True:
                    if event.key == pygame.K_BACKSPACE:
                        user_input = user_input[:-1]
                    elif event.key == pygame.K_KP_ENTER:
                        game_status = "start"
                    else:
                        user_input += event.unicode
        input_surface = font.render(user_input,True,(255,255,255))
    if (keyboard.right):
        new_direction = 'west'
    if (keyboard.left):
        new_direction = 'east'
    elif (keyboard.a):
        new_direction = 'west'
    elif (keyboard.d):
        new_direction = 'east'
    #if len(asteroids) > 1:
    #    print(asteroids[1].spawn)
    for i in range(len(asteroids)):
        if asteroids[i].spawn:
            asteroids[i].location = random.randint(1, 1280)
            asteroids[i].asteroid = Actor("asteroid brown", (asteroids[i].location, 100))
            asteroids[i].visible = True
            asteroids[i].spawn = False

    for ast in asteroids:
        if ast.visible and player.y >= ast.asteroid.y - 25 and (
        player.y <= ast.asteroid.y + 25):
            if ast.visible and player.x >= ast.asteroid.x - 100 and (
            player.x <= ast.asteroid.x + 100):
                health -= 1
                player.x = 640
            if health <= 1 or energy <= 4:
                pointslistpoints["points"] = points
                date = datetime.datetime.strf("Y/m/d/H:M:S")
                pointslistdate["date"] = date
                pointslist = [pointslistpoints, pointslistdate]
                pointsdictname[name] = pointslist
                pointslistfinal.append(pointsdictname)
                with open("C:/Users/helle/mu_code/shooter_game/testfile.txt", "a") as file:
                    json.dump(pointslistfinal, file)
                game_status = "end"
            ast.spawn = True
            ast.visible = False
# when asteroid0 is missed
    if shoot:
        energy -= 0.4
        for ast in asteroids:
            if points >= 0 and ast.visible and (
                laser0.x <= ast.asteroid.x + 64) and laser0.x >= ast.asteroid.x - 64:
                ast.spawn = True
                points += 1
                energy += 5
                ast.visible = False
        shoot = False

    def move_actor(direction, distance=20):
        if (direction == 'west'):
            if not player.x <= 2.5:
                player.x -= distance
        elif (direction == 'east'):
            if not player.x >= 1277.5:
                player.x += distance
    move_actor(new_direction)
    new_direction = "no"